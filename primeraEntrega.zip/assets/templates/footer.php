<footer class="container mx-auto my-10 ">
    
    <img class="col-span-3 mx-auto h-36" src="assets/images/logos2.png">
    <div class="grid grid-cols-8">
        <div class="col-span-7">
            <a class="px-6" href="#">PRIVACIDAD</a>
            <a class="px-6" href="#">LEGAL</a>
            <a class="px-6" href="#">COOKIES</a>
        </div>
        <div class="grid justify-end grid-cols-3 text-menu">
            <a href="#"><img class="h-10" src="assets\images\facebook.png" alt="Logo facebook" srcset=""></a>
            <a href="#"><img class="h-10" src="assets\images\twitter.png" alt="Logo twitter" srcset=""></a>
            <a href="#"><img class="h-10" src="assets\images\instagram.png" alt="Logo instagram" srcset=""></a>    
        </div>
    </div>
</footer>
